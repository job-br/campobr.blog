/**
 * Download de código-fonte / build foi REMOVIDO do site público.
 *
 * Motivo (performance + segurança): o antigo script de build embutia o ZIP do
 * projeto inteiro (em Base64) dentro do JavaScript e o publicava em /download/,
 * inflando o bundle em dezenas de MB e expondo o código-fonte.
 *
 * As funções abaixo permanecem apenas para manter compatibilidade de importação
 * dos componentes existentes; elas não fazem nada.
 */

export function isProjectEnvironment(): boolean {
  return false;
}

export async function downloadDistZipReliable(): Promise<boolean> {
  return false;
}

export async function downloadSourceZipReliable(): Promise<boolean> {
  return false;
}

export const downloadDistZip = downloadDistZipReliable;
export const downloadSourceZip = downloadSourceZipReliable;
